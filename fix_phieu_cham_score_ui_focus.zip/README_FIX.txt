Fix lỗi PhieuCham() got unexpected keyword arguments: 'ten_can_bo_cham', 'so_cau'
+ thêm ô hiển thị điểm quy đổi bên cạnh từng câu
+ sau khi quét QR tự focus vào điểm Câu 1.

Copy 2 file sau vào project:
- exam_token/templates/exam_token/cham_diem_workflow_scan.html
- exam_token/static/exam_token/js/cham_diem_workflow.js

Sau đó sửa model theo patch_snippets/phieu_cham_model_fields.txt và chạy migration.
