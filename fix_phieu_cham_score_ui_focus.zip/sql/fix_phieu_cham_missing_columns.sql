-- Chỉ chạy nếu bạn KHÔNG dùng makemigrations/migrate hoặc DB đang thiếu cột.
-- MySQL 8 hỗ trợ ADD COLUMN IF NOT EXISTS. Nếu MySQL cũ báo lỗi syntax, dùng SHOW COLUMNS rồi thêm từng cột còn thiếu.

ALTER TABLE phieu_cham ADD COLUMN IF NOT EXISTS ten_can_bo_cham VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE phieu_cham ADD COLUMN IF NOT EXISTS so_cau SMALLINT UNSIGNED NOT NULL DEFAULT 2;
ALTER TABLE phieu_cham ADD COLUMN IF NOT EXISTS is_locked BOOL NOT NULL DEFAULT FALSE;
ALTER TABLE phieu_cham ADD COLUMN IF NOT EXISTS locked_at DATETIME NULL;

ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS max_do_lech DECIMAL(5,2) NULL;
ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS hinh_thuc_xu_ly VARCHAR(50) NOT NULL DEFAULT '';
ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS ghi_chu_doi_chieu LONGTEXT NOT NULL;
ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS diem_xu_ly DECIMAL(5,2) NULL;
ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS doi_chieu_done BOOL NOT NULL DEFAULT FALSE;
ALTER TABLE cham_diem_bai_thi ADD COLUMN IF NOT EXISTS published_at DATETIME NULL;
