FIX: thêm chức năng Xem điểm tổng hợp ngoài màn hình

1) Copy file:
   exam_token/templates/exam_token/cham_diem_tong_hop_man_hinh.html
   vào project.

2) Mở exam_token/cham_diem_workflow.py
   Dán toàn bộ nội dung trong:
   patch_snippets/cham_diem_workflow_add_view.py
   xuống cuối file.

3) Mở exam_token/urls.py
   Đảm bảo có:
   from . import cham_diem_workflow as cdw

   Thêm vào urlpatterns:
   path("cham-diem/tong-hop/", cdw.cham_diem_tong_hop_man_hinh, name="cham_diem_tong_hop_man_hinh"),

4) Mở base.html, thêm link menu trong:
   patch_snippets/menu_base_add_link.html

5) Restart server rồi vào:
   http://127.0.0.1:8000/cham-diem/tong-hop/
