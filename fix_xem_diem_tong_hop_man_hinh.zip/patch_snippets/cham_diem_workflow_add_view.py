
@login_required
def cham_diem_tong_hop_man_hinh(request):
    """Trang xem điểm tổng hợp trực tiếp trên màn hình, không cần quét QR trước."""
    if not (is_admin_manager(request.user) or in_groups(request.user, ["giam_khao_1", "giam_khao_2", "truong_hoi_dong", "can_bo_cham_diem"])):
        return HttpResponseForbidden("Bạn không có quyền xem điểm tổng hợp.")

    q = (request.GET.get("q") or "").strip()
    selected_id = (request.GET.get("phien_thi") or "").strip()

    phien_qs = PhienThi.objects.select_related("lop", "mon").order_by("-id")
    if q:
        q_filter = Q(lop__ten_lop__icontains=q) | Q(mon__ten_mon__icontains=q)
        if q.isdigit():
            q_filter = q_filter | Q(id=int(q))
        phien_qs = phien_qs.filter(q_filter)

    phien_list = list(phien_qs[:100])
    selected_pt = None
    rows = []
    cfg1 = cfg2 = None
    required = scored1 = scored2 = 0
    so_cau = 2
    can_open_compare = False

    if selected_id:
        selected_pt = get_object_or_404(PhienThi.objects.select_related("lop", "mon"), pk=selected_id)
        cfg1 = get_config(selected_pt, 1)
        cfg2 = get_config(selected_pt, 2)
        cfg_any = cfg1 or cfg2
        so_cau = int(cfg_any.so_cau if cfg_any else 2)
        required = required_students_count(selected_pt)
        scored1 = scored_students_count(selected_pt, 1)
        scored2 = scored_students_count(selected_pt, 2)
        can_open_compare = required > 0 and scored2 >= required

        assignments = (
            GanTokenBaiThi.objects
            .select_related("hoc_vien", "token")
            .filter(phien_thi=selected_pt, trang_thai__in=COLLECTED_ASSIGN_STATUSES)
            .exclude(trang_thai__in=CANCELLED_ASSIGN_STATUSES)
            .order_by("hoc_vien__so_bao_danh", "hoc_vien_id", "id")
        )

        by_student = {}
        student_order = []
        for a in assignments:
            hv_id = a.hoc_vien_id
            if hv_id not in by_student:
                by_student[hv_id] = {"hoc_vien_id": hv_id, "token_ids": [], "first_assignment": a}
                student_order.append(hv_id)
            token_id = getattr(a.token, "id", "") if a.token_id else ""
            if token_id and token_id not in by_student[hv_id]["token_ids"]:
                by_student[hv_id]["token_ids"].append(token_id)

        bai_by_student = {}
        if student_order:
            bai_qs = (
                ChamDiemBaiThi.objects
                .select_related("gan_token", "gan_token__hoc_vien", "token")
                .prefetch_related(Prefetch(
                    "phieu_cham",
                    queryset=PhieuCham.objects.select_related("nguoi_cham").prefetch_related("chi_tiet").order_by("lan_cham", "id"),
                ))
                .filter(phien_thi=selected_pt, gan_token__hoc_vien_id__in=student_order)
                .order_by("id")
            )
            for bai in bai_qs:
                hv_id = bai.gan_token.hoc_vien_id if bai.gan_token_id else None
                if hv_id and hv_id not in bai_by_student:
                    bai_by_student[hv_id] = bai

        for hv_id in student_order:
            item = by_student[hv_id]
            bai = bai_by_student.get(hv_id)
            phieu1 = phieu2 = phieu3 = None
            s1 = {}
            s2 = {}
            s3 = {}
            diffs = {}
            total_diff = ""
            max_diff = ""
            action_label = ""
            note = "Chưa chấm"
            status = "Chưa chấm"
            final_score = ""
            need_processing = False
            doi_chieu_done = False

            if bai:
                phieus = list(bai.phieu_cham.all())
                phieu1 = next((p for p in phieus if p.lan_cham == 1 and p.trang_thai == "da_nop"), None)
                phieu2 = next((p for p in phieus if p.lan_cham == 2 and p.trang_thai == "da_nop"), None)
                phieu3 = next((p for p in phieus if p.lan_cham == 3 and p.trang_thai == "da_nop"), None)
                s1 = scores_from_phieu(phieu1)
                s2 = scores_from_phieu(phieu2)
                s3 = scores_from_phieu(phieu3)
                final_score = fmt_score(getattr(bai, "diem_chinh_thuc", ""))
                doi_chieu_done = bool(getattr(bai, "doi_chieu_done", False))

                if phieu1 and phieu2:
                    result = classify_score_difference(s1, s2, phieu1.tong_diem, phieu2.tong_diem)
                    diffs = result.question_diffs
                    total_diff = result.total_diff
                    max_diff = result.max_diff
                    need_processing = bool(result.need_processing and not doi_chieu_done)
                    action_label = ACTION_LABELS.get(getattr(bai, "hinh_thuc_xu_ly", "") or result.action, result.action)
                    note = getattr(bai, "ghi_chu_doi_chieu", "") or result.note
                    if doi_chieu_done:
                        status = "Đã xử lý"
                    elif result.need_processing:
                        status = "Cần xử lý lệch"
                    else:
                        status = "Tự động lấy CBCT 2"
                elif phieu1 and not phieu2:
                    status = "Chờ CBCT 2"
                    note = "CBCT 1 đã chấm, CBCT 2 chưa chấm"
                elif phieu2 and not phieu1:
                    status = "Thiếu CBCT 1"
                    note = "Có phiếu CBCT 2 nhưng chưa có phiếu CBCT 1"

            rows.append({
                "bai": bai,
                "token_ids": ", ".join(str(x) for x in item["token_ids"]),
                "phieu1": phieu1,
                "phieu2": phieu2,
                "phieu3": phieu3,
                "scores1": s1,
                "scores2": s2,
                "scores3": s3,
                "diffs": diffs,
                "total_diff": total_diff,
                "max_diff": max_diff,
                "final_score": final_score,
                "action_label": action_label,
                "note": note,
                "status": status,
                "need_processing": need_processing,
                "doi_chieu_done": doi_chieu_done,
            })

    return render(request, "exam_token/cham_diem_tong_hop_man_hinh.html", {
        "q": q,
        "phien_list": phien_list,
        "selected_pt": selected_pt,
        "cfg1": cfg1,
        "cfg2": cfg2,
        "required": required,
        "scored1": scored1,
        "scored2": scored2,
        "so_cau": so_cau,
        "cau_range": range(1, so_cau + 1),
        "rows": rows,
        "can_open_compare": can_open_compare,
    })
