# Trong exam_token/urls.py, thêm route này vào urlpatterns.
# Nhớ đã có: from . import cham_diem_workflow as cdw

path("cham-diem/tong-hop/", cdw.cham_diem_tong_hop_man_hinh, name="cham_diem_tong_hop_man_hinh"),
